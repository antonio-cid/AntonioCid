//
//  MensajesViewController.swift
//  Red-Up
//
//  Created by Macbook on 6/11/19.
//  Copyright © 2019 JDGE. All rights reserved.
//

import UIKit

class MensajesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var mensajeTableView: UITableView!
    
    let mensajeCellId = "mensajeCellId"
    
    var mensajes = [mensaje]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
     //   fileprivate func getEjemploData(){
            let mensaje1 = mensaje()
            mensaje1.mensajetext = "Hola"
            mensaje1.mensajeUserid = 1
            
            let mensaje2 = mensaje()
            mensaje2.mensajetext = "Hola :)"
            mensaje2.mensajeUserid = 2
            
            let mensaje3 = mensaje()
            mensaje3.mensajetext = "Dónde estas?"
            mensaje3.mensajeUserid = 1
            
            let mensaje4 = mensaje()
            mensaje4.mensajetext = "Por donde esta la pizzeria"
            mensaje4.mensajeUserid = 2
            
            mensajes += [mensaje1, mensaje2, mensaje3, mensaje4]
        }
        





        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mensajes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      //  let cell = mensajeTableView.dequeueReusableCell(withIdentifier: mensajeCellId, for: IndexPath) as! MensajeTableViewCell
     //   let mensajes = mensaje[indexPath.row]
        
        cell.mensajeLabel.text = mensajes.mensajetext
        
        if mensajes.mensajeUserid == 0{
            
        }
        
   
        
        
        if indexPath.row % 2 == 0{
            cell.mensajeLabel.textAlignment = .right
        }
        return cell
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
