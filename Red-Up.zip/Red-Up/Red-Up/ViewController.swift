//
//  ViewController.swift
//  Red-Up
//
//  Created by Macbook on 5/28/19.
//  Copyright © 2019 JDGE. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

