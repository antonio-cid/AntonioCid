//
//  MensajeTableViewCell.swift
//  Red-Up
//
//  Created by Macbook on 6/11/19.
//  Copyright © 2019 JDGE. All rights reserved.
//

import UIKit

class MensajeTableViewCell: UITableViewCell {

    @IBOutlet weak var mensajeLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
