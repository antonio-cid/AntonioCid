
//
//  Usuario.swift
//  Red-Up
//
//  Created by Macbook on 5/28/19.
//  Copyright © 2019 JDGE. All rights reserved.
//

import UIKit

class User{
    
    var id: String
    var nombre: String
    var apellido: String
    var telefono: Int
    
    init(id: String, nombre: String, apellido: String, telefono: Int){
        
        self.id = id
        self.nombre = nombre
        self.apellido = apellido
        self.telefono = telefono
        
        
    }
}
