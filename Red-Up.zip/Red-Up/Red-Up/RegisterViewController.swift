//
//  RegisterViewController.swift
//  Red-Up
//
//  Created by Macbook on 5/28/19.
//  Copyright © 2019 JDGE. All rights reserved.
//

import UIKit
import Firebase
import MobileCoreServices
import FirebaseUI

class RegisterViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var nombreNU: UITextField!
    @IBOutlet weak var contactoNU: UITextField!
    @IBOutlet weak var emailNU: UITextField!
    @IBOutlet weak var contraseñaNU: UITextField!
  
    var ref: DocumentReference!
    var getRef: Firestore!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getRef = Firestore.firestore()
        
        let storageReference = Storage.storage().reference()
        
        let userImageDownloadUrlReference = storageReference.child("/photos/picture")
        
        let placeHolderImage = UIImage(named: "fa-image")
        
        //ProfileImageView.sd_sentImage(with: userImageDownloadUrlReference, placeHolderImage: placeHolderImage)
        
        userImageDownloadUrlReference.downloadURL {(url, error) in
            if let error = error{
                
                print(error.localizedDescription)
            }else{
                print("url de descarga: \(String(describing: url!))")
            }
        }
    }
    @IBAction func crearUsuario(_ sender: UIButton) {
        let userImagePicker = UIImagePickerController()
        
        guard let email = emailNU.text, let password = contraseñaNU.text, let nombre = nombreNU.text, let
            telefono = contactoNU.text else { return }
        var datos: [String: Any] = ["Nombre": nombre, "Telefono": telefono]
        
        ref = getRef.collection("User").addDocument(data: datos, completion: { (error) in

            if let error = error{
                print(error.localizedDescription)
            }
            else{
                print("Se guardaron exitosamente los datos")
            }
        })
        
        Auth.auth().createUser(withEmail: email, password: password) { (data, error) in
            if let error = error{
                print(error.localizedDescription)
            }
            
            if let data = data{
                self.getRef.collection("users").document(data.user.uid).setData(datos)
            }
        }
        

    }
    
    
    @IBAction func selectImage(_ sender: UIButton) {
        
        let photoImage = UIImagePickerController()
        photoImage.sourceType = UIImagePickerController.SourceType.photoLibrary
        photoImage.mediaTypes = [kUTTypeImage as String]
        photoImage.delegate = self
        present(photoImage, animated: true, completion: nil)
        
    }
    
    
    //func imagePickerController( _ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]){
        
       // if let imageSelected = info [UIImagePickerController.InfoKey.originalImage] as? UIImage, let optimizedImageData = imageSelected.jpegData(compressionQuality: 0.6){
          
            //(imageData: optimizedImageData)
            //upDataImage()
            
       // }
        //picker.dismiss(animated: true, completion: nil)
    //}
//func imangePickerControllerDidCancel(_ picker: UIImagePickerController){
   // picker.dismiss(animated: true, completion: nil)
//}


    
    //func upDataImage(){
        //guard let image = photoNU.image, let imageData = image.pngData(), let uidUser = Auth.auth().currentUser?.uid else { return }
        //let storageRef = Storage.storage().reference()
        //storageRef.child("/photos").child("\(uidUser).png")
        
        //storageRef.putData(imageData)
    //}
    //func uploadImage(imageData: Data){
        
        //let activityIndicator = UIActivityIndicatorView.init(style: .gray)
        //activityIndicator.startAnimating()
        //activityIndicator.center = self.view.center
        //self.view.addSubview(activityIndicator)
        
        //let storageReference = Storage.storage().reference()
        //let userImageRef = storageReference.child("/photos").child(ref.documentID)
        //let uploadMetadata = StorageMetadata()
        //uploadMetadata.contentType = "image/jpeg"
        
        //(storageMetadata, error) in
            //activityIndicator.stopAnimating()
            //activityIndicator.removeFromSuperview()
            
            //if let error = error{
               // print(error.localizedDescription)
            //}
            //else{
               // print("metadata: ", storageMetadata?.path)
               //true)
            //}
        //}
        
    //}

}
