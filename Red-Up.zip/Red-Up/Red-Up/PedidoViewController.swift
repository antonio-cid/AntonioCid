//
//  PedidoViewController.swift
//  Red-Up
//
//  Created by Macbook on 6/4/19.
//  Copyright © 2019 JDGE. All rights reserved.
//

import UIKit

class PedidoViewController: UIViewController {
    var costo = 0

    @IBOutlet weak var otro: UIButton!
    @IBOutlet weak var banco: UIButton!
    @IBOutlet weak var restaurante: UIButton!
    @IBOutlet weak var entretenimiento: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.

 
        
    }
    
    @IBOutlet weak var precio: UILabel!
    
    @IBAction func didSelectButton(_ sender: UIButton) {
        
        var message = ""
        
        print(sender.tag)
        switch sender.tag {
        case 0:
            message = "Costo por minuto: $2"
        case 1:
            message = "Costo por minuto: $1"
        case 2:
            message = "Costo por minuto: $3"
        case 3:
            message = "Costo por minuto: $4"
        
        default:
            print("opción invalida")
       }
        
        precio.text = message
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
