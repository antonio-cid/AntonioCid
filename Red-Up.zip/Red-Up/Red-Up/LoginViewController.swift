//
//  LoginViewController.swift
//  Red-Up
//
//  Created by Macbook on 5/30/19.
//  Copyright © 2019 JDGE. All rights reserved.
//

import UIKit
import Firebase

class LoginViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        isLogged()

    }
    
    @IBAction func Login(_ sender: UIButton) {
        
        guard let userEmail = email.text, userEmail != "", let userPass = password.text, userPass != "" else{
            
            return
        }
        
        Auth.auth().signIn(withEmail: userEmail, password: userPass) { (user, error) in
            
            if let error = error{
                print(error.localizedDescription)
                return
            }
            
            if user != nil{
                self.isLogged()
            }
        }
        
    }
    
    func isLogged(){
        Auth.auth().addStateDidChangeListener { (auth, user) in
            if user == nil{
                print("No está registrado")
            }
            else{
                print("Sí está registrado")
                
                self.performSegue(withIdentifier: "loggedView", sender: self)
                USERid = self.email.text!
            }
        }
    }
    
    
}
