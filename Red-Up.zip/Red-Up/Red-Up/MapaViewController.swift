//
//  MapaViewController.swift
//  Red-Up
//
//  Created by Macbook on 6/4/19.
//  Copyright © 2019 JDGE. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation


class MapaViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var map: MKMapView!
    
    var manager = CLLocationManager()
    var longitud: CLLocationDegrees!
    var latitud: CLLocationDegrees!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        map.showsUserLocation = true
        manager.delegate = self
        manager.requestWhenInUseAuthorization()

    }
    
    func locationManager( _ manager:CLLocationManager, didUpdateLocations location: [CLLocation]) {
        
        if let location = location.last{
            
            self.longitud = location.coordinate.longitude
            self.latitud = location.coordinate.latitude
            
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            manager.startUpdatingLocation()
        }
    }
    
    @IBAction func getLocation(_ sender: UIButton) {
        
        print(latitud, longitud)
        
        let localizacion = CLLocationCoordinate2D(latitude: latitud!, longitude: longitud!)
        
        let span = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        
        let region = MKCoordinateRegion(center: localizacion, span: span)
        
        map.setRegion(region, animated: true)
        map.showsUserLocation = true
        map.mapType = .hybrid
        
        let anotacion = MKPointAnnotation()
        anotacion.title = "Red- Uper"
        anotacion.subtitle = "servicio"
        anotacion.coordinate = CLLocationCoordinate2D(latitude: 19.435477, longitude: -99.1364789)
        map.addAnnotation(anotacion)
        
        let anotacion2 = MKPointAnnotation()
        anotacion2.title = "Red- Uper"
        anotacion2.subtitle = "servicio"
        anotacion2.coordinate = CLLocationCoordinate2D(latitude: 19.435102, longitude: -99.138123)
        map.addAnnotation(anotacion2)
        
        let anotacion3 = MKPointAnnotation()
        anotacion3.title = "Red- Uper"
        anotacion3.subtitle = "servicio"
        anotacion3.coordinate = CLLocationCoordinate2D(latitude: 19.435744, longitude: -99.143957)
        map.addAnnotation(anotacion3)
        
        let anotacion4 = MKPointAnnotation()
        anotacion4.title = "Red- Uper"
        anotacion4.subtitle = "servicio"
        anotacion4.coordinate = CLLocationCoordinate2D(latitude: 19.434647, longitude: -99.139335)
        map.addAnnotation(anotacion4)
        
        
    }
    

    

}
