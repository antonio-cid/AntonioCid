//
//  mEnsajE.swift
//  Red-Up
//
//  Created by Macbook on 6/12/19.
//  Copyright © 2019 JDGE. All rights reserved.
//

import Foundation

class mensaje: NSObject{
    var mensajetext: String?
    var mensajeUserid: Int?
    
}
