//
//  ProfileViewController.swift
//  Red-Up
//
//  Created by Macbook on 5/31/19.
//  Copyright © 2019 JDGE. All rights reserved.
//

import UIKit
import FirebaseAuth
import Firebase

class ProfileViewController: UIViewController {
    
   

    @IBOutlet weak var nombrerUser: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        Firestore.firestore().collection("users").addSnapshotListener{(snapshot, error) in
            if let error = error{
            debugPrint(error)
            }else{
                for document in (snapshot?.documents)!{
                    //print(document.data())
                    let data = document.data()
                    if (data["Nombre"] != nil){
                        let nombre = data["Nombre"] as! String
                        print(nombre)
                        
                       if (data["Apellido"] != nil){
                        let apellido = data["Apellido"] as! String
                            print(apellido)
                        }
                            
                        if (data["correo"] != nil){
                            let correo = data["correo"] as! String
                            print(correo)
                            if USERid == correo {
                                self.nombrerUser.text = nombre
                                 print(nombre)
                            }
                        }
                        
                        
                    }
                   
                }
            }
    }
    }
    
    
        func logout(_ sender: Any) {
        
    }
    
    @IBAction func signOut(_ sender: Any) {
        try! Auth.auth().signOut()
        self.dismiss(animated: true, completion: nil)
    }
    
        //weak var cargarImagen: UIImageView!
    
    
    
}
